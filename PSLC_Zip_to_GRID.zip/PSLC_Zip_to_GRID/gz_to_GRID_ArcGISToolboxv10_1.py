try:
    '''This tool automatically converts zip files downloaded from the PSLC that contain E00 files.  The e00 files
    are extracted from the zip files in batch and converted to ESRI GRID files in the same directory as the zip files.
    The user can choose to automatically delete the zip files or the e00 files during script execution.
    
    This tool requires ArcGIS version 10 or later.
    The target directory should not contain any other data other than the zip files...
    
    Problems, Crashes, Concerns?  Contact Gerry Gabrisch at geraldg@lummi-nsn.gov
    
    Directions for use:
    Add the ESRI toolbox file .tbx file to ArcToolbox
    Execute like any other toolbox tool...'''
    
    
    import sys, arcpy, traceback, os
    import gzip,os.path
    import glob
    
    arcpy.AddMessage("Converts gz File to ESRI GRID Auto-Converter.")
    arcpy.AddMessage("Created by Gerry Gabrisch GISP, GIS Manager, Lummi Indian Business Council (LIBC) geraldg@lummi-nsn.gov.\n\n")
    
    arcpy.AddMessage("Copy? Right! 2014, This script is distributed freely without any constraints or copyright limitations.\n")
    arcpy.AddMessage("THE LIBC DISTRIBUTES THIS TOOL AS IS. THE LIBC MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE.  THE LIBC SHALL NOT BE LIABLE FOR ANY INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES OR LOSS.\n\n")
    
    
    indir = arcpy.GetParameterAsText(0)
    deletezips = arcpy.GetParameterAsText(1)
    deletee00 = arcpy.GetParameterAsText(2)
    hillshade = arcpy.GetParameterAsText(3)
    
   
    if hillshade == "true":
        try:
            from arcpy.sa import *
            arcpy.CheckOutExtension("Spatial")
        except:
            arcpy.AddMessage("No Spatial Analyst tool found, auto-create hillshades is disabled...")
            hillshade = "false"
                
    arcpy.AddMessage("UnGzipping files...")
    
    
    inzip = indir + "\\*.gz"
    allzips = glob.glob(inzip)
    for gz in allzips:
        arcpy.AddMessage("Working on " + gz)
        filename = gz.split("\\")
        filename = filename.pop()
        filename = filename.split(".")
        filename = filename[0]
        
        inF = gzip.GzipFile(gz, 'rb')
        s = inF.read()
        inF.close()

        outF = file(indir + "\\"+ filename + ".e00", 'wb')
        outF.write(s)
        outF.close()
    
    
    
    
    
    
    
    for zff in allzips:
        arcpy.AddMessage("Unzipping " + zff)
        
        
        if deletezips == "true":
            os.remove(zff)
            
    arcpy.AddMessage("Converting e.00 files...")
    indir2 = indir + "\\*.e00"
    allfiles = glob.glob(indir2)
    for e00 in allfiles:
        arcpy.AddMessage("Working on " + e00)
        filename = e00.split("\\")
        filename = filename.pop()
        filename = filename.split(".")
        filename = filename[0]
        
        arcpy.ImportFromE00_conversion(e00, indir, filename)
        
        if deletee00 == "true":
            os.remove(e00)
            
        if hillshade == "true":
            inRaster = indir + "\\"+ filename
            arcpy.AddMessage("Creating hillshade for " + inRaster)
            outHillShade = Hillshade(inRaster, "", "", "", "")
            outHillShade.save(indir + "\\hs"+ filename)

    arcpy.AddMessage("Finished without error!")
    
except arcpy.ExecuteError: 
    msgs = arcpy.GetMessages(2) 
    arcpy.AddError(msgs)  
    arcpy.AddMessage(msgs)
except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
    arcpy.AddMessage(pymsg)
    print(pymsg + "\n")
    