This tool automatically converts zip files downloaded from the Puget Sound LiDAR Consortium that contain E00 files of LiDAR data.  The e00 files
are extracted from the zip files in batch and converted to ESRI GRID files in the same directory as the zip files.

The user can choose to automatically delete the zip files automatically delete e00 files, or automatically create hillshades during script execution.
    
This tool requires ArcGIS version 10 or later.

    
Problems, Crashes, Concerns?  Contact Gerry Gabrisch at geraldg@lummi-nsn.gov
    
    
Directions for use:
Put the zipped e00 files into a single directory. The target directory should not contain any other data other than the zip files.
Add the ESRI toolbox file PSLCimporter.tbx file to ArcToolbox
In ArcToolbox expand the PSLCimport toolbox to see the PSLC zip to grid scripting tool.
Double click the PSLC zip to grid scripting tool

Set model parameters:

The directory of zip files. == the location of downloaded zip files
Delete the zip fiels when finished (optional) = Deletes the zip file and all its contents after the e00 file is extracted from the zip.
Delete e00 files when finished (optional) = After an ESRI GRID file is created the e00 file is deleted.
Auto-Create Hillshade (optional) = Creates a hillshade file called hs<filename> using the hillshade defaults for azimuth, angle, z factor...